<?php

declare(strict_types=1);

namespace QBExport\Exception;

class QBAuthorizationException extends \Exception
{

}
